import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from django.shortcuts import render
from sklearn.preprocessing import LabelEncoder

#loadinf the data
data = pd.read_csv("C:/Users/rujut/Downloads/cleaned_dataset.csv")

# Preprocess the data
le = LabelEncoder()
data['HeartDisease'] = le.fit_transform(data['HeartDisease'])

#creating the training model
rf = RandomForestClassifier(n_estimators=100,random_state=42)
data.dropna(inplace=True)
print()

#rf.fit(data.drop('HeartDisease', axis=1),data['HeartDisease'])

def predict(request):
    if request.method == 'POST':
        age = request.POST.get('age')
        sex = request.POST.get('sex')
        cp = request.POST.get('cp')
        trestbps = request.POST.get('trestbps')
        chol = request.POST.get('chol')
        fbs = request.POST.get('fbs')
        restecg = request.POST.get('restecg')
        thalach = request.POST.get('thalach')
        exang = request.POST.get('exang')
        oldpeak = request.POST.get('oldpeak')
        slope = request.POST.get('slope')
        ca = request.POST.get('ca')
        thal = request.POST.get('thal')
        
        # create a dataframe with user input
        input_df = pd.DataFrame([[age, sex, cp, trestbps, chol, fbs, restecg, thalach, exang, oldpeak, slope, ca, thal]],
                               columns=['Age', 'Sex', 'ChestPain', 'RestBP', 'Cholesterol', 'FastingSugar', 
                                        'RestECG', 'MaxHR', 'ExerciseInducedAngina', 'STDepression', 'Slope', 'NumMajorVessels', 
                                        'Thalassemia'])
        
        # predict the possibility of heart attack
        prediction = rf.predict(input_df)[0]
        
        return render(request, 'result.html', {'prediction': prediction})
    else:
        return render(request, 'index.html')
