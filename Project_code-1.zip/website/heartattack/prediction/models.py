import joblib
import numpy as np
from django.conf import settings
import os
import pandas as pd
...
model_path = os.path.join(settings.BASE_DIR, 'heartattack/train_model.py')




# Load the trained model
model = joblib.load(model_path)

# Define the function to make predictions
def predict_heart_disease(data):
    """
    Make a prediction of heart disease using the trained model and new data
    :param data: a dictionary containing the input data
    :return: a dictionary containing the predicted output
    """
    # Convert the input data into a numpy array
    input_data = np.array([[
        data['age'], data['sex'], data['cp'], data['trestbps'], 
        data['chol'], data['fbs'], data['restecg'], data['thalach'], 
        data['exang'], data['oldpeak'], data['slope'], data['ca'], 
        data['thal']
    ]])

    # Make the prediction
    prediction = model.predict(input_data)

    # Convert the prediction to a string label
    if prediction == 0:
        label = 'No heart disease'
    else:
        label = 'Heart disease'

    # Create the output dictionary
    output = {
        'prediction': label
    }

    return output
