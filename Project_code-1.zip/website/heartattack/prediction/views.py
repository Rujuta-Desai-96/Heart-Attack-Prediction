from django.shortcuts import render
from django.urls import path
from .models import HeartDisease
from .model import predict_heart_disease

def predict(request):
    if request.method == 'POST':
        # Get the input values from the user
        age = request.POST['age']
        sex = request.POST['sex']
        cp = request.POST['cp']
        trestbps = request.POST['trestbps']
        chol = request.POST['chol']
        fbs = request.POST['fbs']
        restecg = request.POST['restecg']
        thalach = request.POST['thalach']
        exang = request.POST['exang']
        oldpeak = request.POST['oldpeak']
        slope = request.POST['slope']
        ca = request.POST['ca']
        thal = request.POST['thal']

        # Create a dictionary with the input values
        input_data = {
            'age': age,
            'sex': sex,
            'cp': cp,
            'trestbps': trestbps,
            'chol': chol,
            'fbs': fbs,
            'restecg': restecg,
            'thalach': thalach,
            'exang': exang,
            'oldpeak': oldpeak,
            'slope': slope,
            'ca': ca,
            'thal': thal
        }

        # Make the prediction
        prediction = predict_heart_disease(input_data)

        # Save the input and output to the database
        hd = HeartDisease(
            age=age,
            sex=sex,
            cp=cp,
            trestbps=trestbps,
            chol=chol,
            fbs=fbs,
            restecg=restecg,
            thalach=thalach,
            exang=exang,
            oldpeak=oldpeak,
            slope=slope,
            ca=ca,
            thal=thal,
            prediction=prediction['prediction']
        )
        hd.save()

        # Render the result template with the prediction
        return render(request, 'result.html', {'prediction': prediction['prediction']}, name='result')

    else:
        return render(request, 'index.html')
