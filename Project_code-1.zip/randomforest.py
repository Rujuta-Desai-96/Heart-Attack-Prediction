import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix

#loadinf the data
data = pd.read_csv("C:/Users/rujut/Downloads/Dataset.csv")

#split the data into training and testing model
x = data.drop('HeartDisease', axis=1)
y = data['HeartDisease']
x_train, x_test, y_train, y_test = train_test_split(x,y,test_size=0.2, random_state=42)

#creating the training model
rf = RandomForestClassifier(n_estimators=100,random_state=42)
rf.fit(x_train,y_train)

#evaluate the performance
y_pred = rf.predict(x_test)
print("Accuracy",accuracy_score(y_test,y_pred))
print("Precision",precision_score(y_test,y_pred))
print("Recall",recall_score(y_test,y_pred))
print("F1 score",f1_score(y_test,y_pred))

#heat map for the predicted data


# get the predicted labels
y_pred = rf.predict(x_test)

# create the confusion matrix
cm = confusion_matrix(y_test, y_pred)

# create a heatmap of the confusion matrix
sns.heatmap(cm, annot=True, cmap='Blues')
plt.xlabel('Predicted labels')
plt.ylabel('True labels')
plt.show()
plt.savefig('confusion_matrix.png')