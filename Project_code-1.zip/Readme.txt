

To run this application you need to have the following:

1\. NodeJS

2\. Python 3.7 or higher

Client Side:

1\. cd client/bt-ps

2\. Install all node package using npm install ( Use npm install --force if not working.)

3\. Finally, npm start

Server Side:

1\. cd Server

2\. Python backend-flask-code.py

We've attached the Jupyter notebook files of the 3 models we've used for the prediction.

We've constructed the website using django. The 'heartattack' folder contains all the necessary files required to run the application.